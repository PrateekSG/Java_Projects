package com.bookapp.exception;

public class CategoryNotFoundException extends Exception {

	public CategoryNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
