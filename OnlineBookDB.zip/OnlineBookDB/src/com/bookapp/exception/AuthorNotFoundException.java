package com.bookapp.exception;

public class AuthorNotFoundException extends Exception {

	public AuthorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
